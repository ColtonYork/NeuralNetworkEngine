#include <string>
#include <algorithm>


namespace UIutils
{
    std::string to_upper(const std::string& s);
}