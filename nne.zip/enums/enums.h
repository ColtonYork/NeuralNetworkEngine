#pragma once



enum class ActivationFunction { None, Sigmoid, Relu };
enum class LayerType { None, Dense, Recurrent };
