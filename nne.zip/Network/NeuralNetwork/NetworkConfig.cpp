# include "NetworkConfig.h"


void NetworkConfig::outputNetworkConfigData() const
{
    std::cout << "  " <<
    UIutils::to_upper(network_name) << " CONFIGURATION DATA        "
    "---------------------------------------------------------------"
    

}
