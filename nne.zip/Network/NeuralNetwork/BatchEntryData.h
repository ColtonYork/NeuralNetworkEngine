class BatchEntryData
{




};